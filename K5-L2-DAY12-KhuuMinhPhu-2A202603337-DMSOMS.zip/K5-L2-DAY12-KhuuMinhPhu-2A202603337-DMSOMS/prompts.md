# Khai báo dùng AI — Khưu Minh Phú

Nhắc lại: không đưa ảnh cabin hay ảnh tài xế (kể cả ảnh chụp màn hình) cho bất kỳ công cụ AI nào.

| # | Công cụ | Bạn hỏi gì (tóm tắt) | Bạn dùng kết quả thế nào | Bạn có kiểm lại không? Bằng gì? |
|---|---|---|---|---|
| 1 | Antigravity AI | Tóm tắt quy trình các bước làm bài lab Ngày 12 và các lưu ý trong Guideline Cabin v1.0 cho mã G07 | Dùng làm checklist thứ tự thao tác trên CVAT (đặt tag `frame_meta` trước, quy tắc ghế theo xe, trái/phải theo người trên ảnh xoay 90°) | Có, đối chiếu trực tiếp với `GUIDE.md`, `CHECKPOINTS.md` và `COMMON_ERRORS.md` |
| 2 | Antigravity AI | Hỏi cách xử lý theo Guideline khi người ngồi ghế sau bị tóc che gần hết mặt chỉ lộ một chút mũi và miệng (`S02`), cách phân biệt `infant_seat` không có tay xách với `child_seat`| Vẽ `face` với thuộc tính `unknown` và `occluded=1` ở `S02` và phân biệt được `infant_seat`với `child_seat` | Có, kiểm tra lại từng mục trong `GUIDE.md` |
