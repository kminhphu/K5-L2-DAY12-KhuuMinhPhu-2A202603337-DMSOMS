# Tự đánh giá — Khưu Minh Phú · G07

## 1. Tự rà soát 4 cảnh

Nghỉ tay 1 phút, mở lại bài của mình, chọn 4 ảnh (2 S##, 2 D##), đọc như người lạ.

Loại lỗi: `seat_flip`, `wrong_class`, `guess`, `box`, `missing`, `extra`, `lr_flip` (trái/phải mặt), `flag` (thiếu cờ điểm), `ok`.

| Ảnh | Đối tượng | Loại lỗi | Ghi chú | Đã sửa? |
|---|---|---|---|---|
| `S02_rgb.png` | `infant_seat` & `person` | `seat_flip` | Lần gán đầu tiên bị nhầm trái/phải theo khung ảnh (`infant_seat` bên trái ảnh gán `rear_left`, `person` bên phải ảnh gán `rear_right`); đã đảo lại đúng theo xe (`rear_right` và `rear_left`) | Đã sửa |
| `S07_ir.png` | `object` (`box`) & `child_seat` | `seat_flip` | Hộp `object` ở ghế bên trái ảnh (`x=[210,377]`) ban đầu gán `rear_left`, đã sửa thành `rear_right`; ghế `child_seat` ở giữa giữ nguyên `rear_middle` | Đã sửa |
| `D04.png` | `face` & `face13` | `flag` | Ban đầu vẽ 13 điểm `face13`, phần mắt bị che nhưng quên bật cờ `occluded`; đã bật `occluded=1` cho cả 8 điểm mắt khớp với `eye_left=unknown`, `eye_right=unknown` | Đã sửa |
| `D06.png` | `face` & `face13` | `ok` | Ảnh xoay 90°, đã kiểm tra tọa độ trục `y`: `left_eye_outer` (`y=739.5`) lớn hơn `right_eye_outer` (`y=634.3`), 4 điểm mắt trái khuất đã bật `occluded=1` khớp với `eye_left=unknown` | Đã đúng |

## 2. Lỗi mình lặp lại nhiều nhất hôm nay

Lỗi: `seat_flip` — Gán thuộc tính `seat` trên ảnh OMS (`S02`–`S08`) theo phía trái/phải của bức ảnh thay vì theo hướng của xe.

Vì sao mình mắc: Theo phản xạ tự nhiên khi nhìn vào màn hình, thấy vật nằm bên trái khung ảnh thì chọn ngay `rear_left` và bên phải khung ảnh thì chọn `rear_right`, quên mất rằng camera OMS đặt ở phía trước nhìn ngược về đuôi xe nên hai bên trái/phải bị đảo ngược. Ngoài ra `cabin_check.py` không có đáp án GT nên không báo `[ERROR]` cho lỗi này.

Lần sau tránh bằng cách: Trước khi chọn `seat`, luôn nhẩm quy tắc **"Trái ảnh (`x < 400`) = `rear_right`, Phải ảnh (`x > 520`) = `rear_left`"** và kiểm tra lại tọa độ `x` của từng box sau khi gán xong.

## 3. Ghi chú về disagreement_log

Một dòng bạn của mình đúng và mình sai (hoặc điểm khác biệt phát hiện khi đối chiếu): Qua việc rà soát chéo tọa độ và thuộc tính theo Guideline mục 4.4-3 (ghế gọi theo xe) và mục 4.6 (bật cờ `occluded` cho các điểm `face13` bị che khuất bởi kính/phản xạ), mình học được rằng hai người gán trùng nhau chỉ phản ánh tính nhất quán, còn muốn đúng phải đối chiếu từng thuộc tính với quy tắc gốc của Guideline.
