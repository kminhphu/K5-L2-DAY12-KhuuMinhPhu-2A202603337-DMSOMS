# Danh sách lớp v0 — Khưu Minh Phú · G07

Viết tiếp từ slide 54 bài giảng. Mỗi lớp trả lời: **model cần nhận ra cái này để làm gì?**

## DMS (ít nhất 6 lớp)

| # | Lớp / thuộc tính | Giá trị | Để làm gì (chức năng DMS) | Nhìn thấy được trên IR? |
|---|---|---|---|---|
| 1 | `face.eye_left` / `face.eye_right` | `open` / `closed` / `unknown` | Theo dõi tần suất chớp mắt (PERCLOS) và thời gian nhắm mắt liên tục để phát hiện tài xế buồn ngủ hoặc ngủ gật | Có, rất rõ cả ngày lẫn đêm; trừ khi bị đốm phản xạ LED trên tròng kính hoặc kính râm chắn NIR |
| 2 | `face.gaze_zone` | `road`, `mirror_l`, `mirror_r`, `mirror_c`, `cluster`, `center`, `lap`, `other` | Phát hiện tài xế mất tập trung thị giác (nhìn lệch khỏi đường quá ngưỡng thời gian an toàn, ví dụ nhìn xuống đùi hoặc màn hình trung tâm) | Có, suy ra từ hướng đầu và vị trí đồng tử nếu mắt không bị loá kính |
| 3 | `face.glasses` | `none` / `clear` / `sun` / `unknown` | Cảnh báo độ tin cậy của nhánh ước lượng mắt/gaze và điều chỉnh thuật toán chống lóa khi tài xế đeo kính cận hoặc kính râm | Có (nhận biết qua gọng kính và phản xạ LED trên tròng, dù tròng kính râm có thể trở nên trong suốt dưới tia NIR) |
| 4 | `face13` (13 điểm mốc mặt) | Tọa độ `(x, y)` + cờ `occluded` / `outside` | Ước lượng góc quay đầu 3D (yaw, pitch, roll), độ mở mắt (EAR) và độ mở miệng (MAR - phát hiện ngáp) | Có, nhìn rõ cấu trúc hình học mắt, mũi, miệng trên ảnh NIR thật |
| 5 | `hand` (`side`, `on_wheel`) | `left` / `right` · `yes` / `no` / `unknown` | Kiểm tra tài xế có giữ tay trên vô lăng hay không (Hands-On-Wheel Detection) để cảnh báo hoặc quyết định chuyển giao quyền lái L2/L3 | Có, nhận diện tốt qua hình dáng bàn tay và vị trí tương đối với vành vô lăng |
| 6 | `phone` (`state`) | `held` / `mounted` / `lap` | Phát hiện hành vi sử dụng điện thoại khi lái xe (cầm tay, nghe gọi, nhắn tin) gây xao nhãng nhận thức và thao tác | Có (nhận diện qua hình dáng chữ nhật, góc cạnh hoặc màn hình phát sáng, nhưng khó hơn RGB khi máy tối màu) |
| 7 | `person.seatbelt` (driver) | `worn_correct` / `worn_incorrect` / `not_worn` / `unknown` | Cảnh báo tài xế chưa thắt dây an toàn hoặc thắt sai quy cách (luồn dưới nách/sau lưng) trước và trong khi xe di chuyển | Có, nếu dải dây không bị tiệp hoàn toàn vào màu áo dưới ánh sáng NIR |

## OMS (ít nhất 6 lớp)

| # | Lớp / thuộc tính | Giá trị | Để làm gì (chức năng OMS) | Nhìn thấy được trên IR? |
|---|---|---|---|---|
| 1 | `person` (`seat`) | `front_passenger`, `rear_left`, `rear_middle`, `rear_right` | Đếm số lượng hành khách và xác định vị trí ghế có người ngồi để điều khiển hệ thống điều hòa, nhắc dây an toàn và cứu hộ khi tai nạn | Có (nhận diện tốt qua hình khối cơ thể ngay cả khi cabin tắt đèn) |
| 2 | `person.seatbelt` (hành khách) | `worn_correct` / `worn_incorrect` / `not_worn` / `unknown` | Nhắc nhở thắt dây an toàn cho từng vị trí ghế hành khách (Rear Seatbelt Reminder theo chuẩn Euro NCAP) | Một phần (rõ khi dây tương phản với áo; dễ thành `unknown` nếu vùng ngực bị bóng tối hoặc áo hấp thụ tia IR) |
| 3 | `infant_seat` (`seat`, `facing`) | `rear` / `front` theo từng ghế | Nhận diện nôi trẻ sơ sinh (đặc biệt loại quay ngược `rear-facing`) để tự động vô hiệu hóa túi khí ghế phụ hoặc cảnh báo bỏ quên trẻ (CPD) | Có, nhận diện rõ qua hình dáng vỏ nôi nghiêng và hướng lắp đặt |
| 4 | `child_seat` (`seat`, `occupied`) | `no` / `unknown` (và mở rộng `yes`) | Phân biệt ghế trẻ em đang trống với ghế có trẻ hoặc có đồ vật để tránh báo động giả cho hệ thống Child Presence Detection | Có, dựa vào khung tựa lưng cao và lòng ghế, trừ khi bị chăn/áo trùm kín |
| 5 | `object` (`seat`, `type`) | `bag` / `box` / `cup` / `other` | Phát hiện đồ vật bỏ quên trên ghế sau (nhắc hành khách trước khi khóa xe) và tránh nhầm đồ vật nặng trên ghế với người ngồi | Có về mặt hình dạng (shape), nhưng mất thông tin màu sắc và họa tiết nên khó phân biệt vật có hình khối gần giống nhau |
| 6 | `frame_meta.camera_blocked` | `yes` / `no` | Phát hiện camera cabin bị che khuất hoặc hỏng để hệ thống DMS/OMS phát cảnh báo lỗi cảm biến thay vì đưa ra dự đoán sai | Có (nhận biết khi toàn khung hình tối đen, bão hòa sáng hoặc mất toàn bộ cấu trúc nền cabin) |

## 2 câu hỏi leo thang

Câu hỏi bạn muốn hỏi người viết guideline (hoặc khách hàng) vì guideline v1.0 chưa trả lời. Mỗi câu kèm **tên khung** làm ví dụ.

1. Câu hỏi: Trên ảnh OMS hàng ghế sau, khi hành khách người lớn bị tóc xõa che khuất hoàn toàn hai mắt và trán, chỉ còn lộ một phần nhỏ chóp mũi và miệng, ngưỡng che khuất cụ thể (theo tỷ lệ % diện tích mặt hoặc số bộ phận mắt/mũi/miệng còn thấy) để quyết định **vẽ box `face` (với cờ `occluded=1`, thuộc tính `unknown`)** hay **không vẽ box `face`** là gì?
   Khung ví dụ: `G07 S02_rgb.png`, `G07 S02_ir.png` (hành khách ở ghế `rear_left`, bên phải ảnh).
   Bạn tạm gán thế nào và vì sao: Tạm vẽ box `face` ôm vùng mặt, bật `occluded=1` và đặt `eye_left=unknown`, `eye_right=unknown`, `glasses=unknown`, `gaze_zone=other`, vì theo mục 4.5 chỉ khi "không thấy cả mắt lẫn mũi" mới không vẽ box `face`, ở đây vẫn còn thấy một phần mũi và miệng.
2. Câu hỏi: Trong bộ ảnh thực tế xuất hiện mô hình trẻ em/em bé đang ngồi bên trong `child_seat` và `infant_seat`, nhưng Guideline v1.0 mục 3 ghi *"Bộ ảnh không có trẻ em ngồi. Thấy hình giống trẻ em thì báo coach, không gán"* và thuộc tính `child_seat.occupied` chỉ cho phép `no` hoặc `unknown` (không có `yes`). Ở phiên bản Guideline tiếp theo, khách hàng muốn bổ sung giá trị `occupied = yes` kèm lớp `child`, hay vẫn gán box `child_seat`/`infant_seat` bên dưới rồi bỏ qua đứa trẻ?
   Khung ví dụ: `G07 S01_rgb.png` / `S01_ir.png`, `S03_rgb.png` / `S03_ir.png`, `S05_rgb.png` / `S05_ir.png`, `S08_rgb.png` / `S08_ir.png`.
   Bạn tạm gán thế nào và vì sao: Tuân thủ đúng quy tắc mục 3 ("Thấy hình giống trẻ em thì báo coach, không gán"), không vẽ box cho vị trí ghế có mô hình trẻ em ngồi và chỉ gán đầy đủ các đối tượng ở các ghế còn lại cùng tag `frame_meta`.
