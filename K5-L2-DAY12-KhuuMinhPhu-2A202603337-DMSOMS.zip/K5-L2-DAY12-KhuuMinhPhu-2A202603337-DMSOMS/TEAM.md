# TEAM — Ngày 12

Mã bộ ảnh: **G07** · Hình thức: cá nhân

| Họ tên | MSSV | Đã gán đủ 22 ảnh? | Review chéo với (peer diff) | Số dòng disagreement đã xử lý |
|---|---|---|---|---|
| Khưu Minh Phú | 2A202603337 | có | Cá nhân (đối chiếu bản gán v1 và bản rà soát v2 theo Guideline) | 10 |

Ca vẫn còn mơ hồ trong Guideline và ghi chú báo coach (ghi tên ảnh + đối tượng):

- `G07 S01, S03, S05, S08`: ghế có mô hình trẻ em/em bé ngồi trong `child_seat` / `infant_seat` (theo GUIDE §3 dòng 53 báo coach và không gán).
- `G07 S02_rgb, S02_ir`: hành khách ghế `rear_left` bị tóc xõa che kín hai mắt, chỉ lộ một chút mũi và miệng (gán box `face` với `occluded=1` và thuộc tính `unknown`).

## Cá nhân

### KhuuMinhPhu-2A202603337
- Phần mình làm (ngoài 22 ảnh của mình, ví dụ ai review ai, ai tổng hợp ca hỏi coach): Làm cá nhân toàn bộ 22 ảnh bộ G07, chạy tự kiểm `cabin_check.py` qua các mốc Checkpoint A, B, Final, đối chiếu bản gán đầu (v1) với bản rà soát tọa độ theo Guideline (v2) trong `disagreement_log.csv`, sửa triệt để lỗi đảo ghế `rear_left`/`rear_right` và hoàn thiện toàn bộ báo cáo E1–E5.
- Điều mình học được hôm nay: Hiểu rõ quy ước gắn tọa độ ghế theo hệ quy chiếu của xe (`rear_right` nằm bên trái ảnh khi camera nhìn về sau) và quy ước trái/phải theo cơ thể người lái trên ảnh NIR xoay 90° (`left_eye` có `y` lớn hơn `right_eye`), cũng như nguyên tắc không suy đoán (`unknown` + cờ `occluded`) khi thông tin bị mất trên ảnh hồng ngoại.
